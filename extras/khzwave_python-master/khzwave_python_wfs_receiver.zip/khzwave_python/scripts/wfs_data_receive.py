#!/usr/bin/env python
"""Pulse-to-pulse feedback using epics variables

Available

The data path is below, with the interfaces all done using queues

    p4p subscribers -> epics_read -> algo -> epics_write

A separate control task will also be run in a separate loop, but as
everything is driven by the simulator, this should be kept separate.

A setup coroutine is also available for use, but again, should likely not
be used."""
import os
import asyncio
import socket
import pickle
from time import time_ns
import numpy as np

# Faster loop handling
# ~ import uvloop
# ~ asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

from khzwave.zaber import ZaberStage

from ruamel.yaml import YAML
import zmq
import zmq.asyncio


import logging

logging.basicConfig()


def bypass(inputs):
    return inputs


class Controller:

    def __init__(self, ctype="pid"):
        self.set_ctype(ctype)
        self.bypass = False
        self.setpoint = 338.
        self.highlim = 4.
        self.lowlim = -4.
        
        self.LOG = logging.getLogger("control")

    def set_algo_vars(self, invars:dict):

        extra_keys = []

        # Sanitize keys
        for k in invars.items():
            if k not in self.av.keys():
                 extra_keys.append(k)

        if len(extra_keys) > 0:
            raise ValueError(f"Extra algo vars requested: {extra_keys}. Should be one of {self.av.keys()}")

        # Set values
        self.av.update(invars)
        return self.av

    def set_bypass(self, bypass=True):
        """Set bypass flag for controller to pass through inputs directly"""
        self.bypass = bypass
        return self.bypass

    def set_ctype(self, ctype):
        if ctype == "pid":
            self.algo = self.pid
            #self.av = {"Kp": .2, "Ki": 0.005, "Kd": 0.04, "accum": 0.0, "lasterr" : 0.0}
            #no overshoot Ziegler Nichols
            self.av = {"Kp": .08, "Ki": 0.008, "Kd": 0.528, "accum": 0.0, "lasterr" : 0.0}
            #some overshoot Ziegler Nichols
            #self.av = {"Kp": .132, "Ki": 0.0132, "Kd": 0.88, "accum": 0.0, "lasterr" : 0.0}
            #revised no overshoot
            self.av = {"Kp": .12, "Ki": 0.008, "Kd": 0.528, "accum": 0.0, "lasterr" : 0.0}            
        elif ctype == "ml":
            self.algo = self.ml
            # Initialize ml class
            self.av = {"main": ml()}
        else:
            return ValueError("Unrecognized algorithm requested %s" % ctype)

    def pid(self, inputs):
        """PID controller code"""

        # Calculate algorithm statevars and internals
        error = self.setpoint - inputs

        # Proportional error
        error_p = self.av["Kp"] * error

        # Differential error
        error_diff = error - self.av["lasterr"]
        error_d = self.av["Kd"] * error_diff
        self.av["lasterr"] = error

        # Integral error
        self.av["accum"] += self.av["Ki"] * error

        # Test limits and correct for accumulator
        # TODO better accumulator value limits to fix dead zones caused by them being the same as the output as a whole
        if self.av["accum"] > self.highlim:
            self.av["accum"] = self.highlim
        if self.av["accum"] < self.lowlim:
            self.av["accum"] = self.lowlim

        # Calculate output
        output = self.av["accum"] + error_p + error_d

        #if output > self.highlim:
        #    output = self.highlim
        #if output < self.lowlim:
        #    output = self.lowlim

        return output

    def ml(self, inputs):
        """Perform necessary functions to run through ML algorithm

        This includes first time setup by creating a manager class that will
        be used in all later calls"""

        return self.av["main"].process(inputs)


    def __call__(self, inputs):
        if self.bypass:
            return inputs
        return self.algo(inputs)

pid_controller = Controller()

def pid(inputs):
    return pid_controller(inputs)


algo_funcs = {
    "bypass": bypass,
    "pid": pid,
#    "ml": ml,
}

async def udp_read(yaml, queue: asyncio.Queue, address=None):
    LOG = logging.getLogger("udp_read")   

    sendip = yaml["sendip"]
    rxip = yaml["rxip"]
    port = yaml["port"]

    LOG.info("Initializing UDP receive loop")
    while True:
        start = time_ns()

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)  # UDP
        # sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.bind((rxip, port))
        msg = sock.recv(2048)
        sock.close()

        # msglen = msg[:2]
        # msglen = int.from_bytes(msglen, 'big')
        # read_data = pickle.loads(msg[2:])
        try:
            read_data = pickle.loads(msg)
        except Exception as e:
            LOG.error("Exception while unpickling idx %d: %s" % (idx, e))

        LOG.debug("Received data: %s" % read_data)

        # Get a "work item" out of the queue.
        await queue.put(read_data)
        await queue.join()
        end = time_ns()
        LOG.debug("Loop took %d ns" % (end - start))


async def zmq_read(yaml, queue: asyncio.Queue, address="tcp://127.0.0.1:5555"):
    """Subscribes to READPVS and aggregates data into a single item for algorithm"""

    LOG = logging.getLogger("zmq_read")

    # Start zmq context
    ctx = zmq.asyncio.Context()
    sock = ctx.socket(zmq.SUB)

    # Move monitor to separate thread and track data in out with queues
    monitor = sock.get_monitor_socket()

    LOG.debug("Connecting to %s" % address)
    sock.connect(address)
    sock.subscribe("")

    while True:
        LOG.debug("awaiting data")

        # TODO change to faster method of bytes receiving (numpy array sizes, etc)
        read_data = await sock.recv_pyobj()

        LOG.debug("Received data: %s" % read_data)

        # Get a "work item" out of the queue.
        await queue.put(read_data)
        await queue.join()

        # Sleep for the "sleep_for" seconds.
        # await asyncio.sleep(wait_time)


async def algo(
    yaml,
    algo_queue: asyncio.Queue,
    read_queue: asyncio.Queue,
    write_queue: asyncio.Queue,
):
    """Runs input data to algorithm and can update algorithm based on queue updates"""

    LOG = logging.getLogger("algo")
    set_algo = await algo_queue.get()
    LOG.info("Setting initial algorithm to %s" % set_algo)
    while True:
        # Get a "work item" out of the queue.
        in_item = await read_queue.get()

        # Run algorithm
        out_item = set_algo(in_item["roc"])

        # Notify the queue that the "work item" has been processed.
        read_queue.task_done()

        # Process output data
        outval = int(out_item * 1e6 * 0.5)

        LOG.debug("Sending to stage: %d" % outval)

        # Write out new values
        if yaml["use_stage"]:
            await write_queue.put(outval)
            await write_queue.join()

        # Update algorithm if requested
        try:
            set_algo = await algo_queue.get_nowait()
            LOG.info("Updating algorithm to %s" % set_algo)
        except asyncio.QueueEmpty:
            pass


async def zaber_write(yaml, queue: asyncio.Queue):
    """Writes received data from algorithm to epics control variables"""

    LOG = logging.getLogger("zaber_write")
    if yaml["save_data"]["save"]:
        import h5py

        hf = h5py.File("new file")

    # Do necessary processing to write to Zaber stage
    stage = ZaberStage()
    await stage.open_asyn()

    #start_pos = stage.get_pos()
    #LOG.info("Stage is at %d" % start_pos)

    # idx = 0
    while True:
        # Get a "work item" out of the queue.
        read_item = await queue.get()
        LOG.debug("Received %d" % read_item)

        if yaml["save_data"]["save"]:
            grp.require_group(f"{idx}_data")
            grp.create_dataset("data", data=read_item["roc"])

        start = time_ns()
        # Move stage with relative adjustment from controller
        xx = await stage.move_relative(read_item)
        LOG.debug("%s" % xx)
        # if b"BUSY" in xx:
            # await stage.wait_idle()
        end = time_ns()
        LOG.debug("Move took %d ns" % (end - start))

        # Notify the queue that the "work item" has been processed.
        queue.task_done()
        # idx += 1


async def main(yaml, algo_str, address):
    LOG = logging.getLogger("main")

    # Load algorithm function into queue
    algo_queue = asyncio.Queue(2)
    set_algo = algo_funcs[algo_str]
    await algo_queue.put(set_algo)
    LOG.info(
        "set_algo = %s algo_funcs[algo_str] = %s algo_str = %s"
        % (set_algo, algo_funcs[algo_str], algo_str)
    )

    # Creating read and write data queues
    read_queue = asyncio.Queue(10)
    write_queue = asyncio.Queue(10)


    # Kick off tasks, handling UDP vs zmq case
    if yaml["use_zmq"]:
        read_thread= zmq_read
        read_yaml = yaml["receive"]
    else:
        read_thread= udp_read
        read_yaml = yaml

    # Kick off tasks
    results = await asyncio.gather(
        read_thread(read_yaml, read_queue, address=address),
        algo(yaml["receive"], algo_queue, read_queue, write_queue),
        zaber_write(yaml["receive"], write_queue),
    )

    # Python 3.11 and above
    # ~ async with asyncio.TaskGroup() as tg:
    # ~ rtask = tg.create_task("epics_read", epics_read(ctxt, read_queue, VARS_EPICS_READ))
    # ~ atask = tg.create_task("algorithm", algo(algo_queue,read_queue,write_queue))
    # ~ wtask = tg.create_task("epics_write", epics_write(ctxt,read_queue))


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(
        description="Receive data from WFS20 0mq and write to Zaber stage"
    )
    parser.add_argument(
        "-a",
        "--algo",
        default="pid",
        choices=algo_funcs.keys(),
        type=str,
        help="algorithm to use",
    )
    parser.add_argument(
        "-s",
        "--server",
        default="tcp://127.0.0.1:5555",
        type=str,
        help="address to subscribe to",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="use info level output"
    )
    parser.add_argument(
        "-vv", "--vverbose", action="store_true", help="use debug level output"
    )
    parser.add_argument("yaml", type=str, help="YAML file for algorithm definition")
    args = parser.parse_args()

    # Logging level default verbosity
    LOG = logging.getLogger()

    if args.verbose:
        LOG.setLevel(logging.INFO)

    if args.vverbose:
        LOG.setLevel(logging.DEBUG)

    # Load YAML configuration for algorithms
    yaml = YAML(typ="safe")  # default, if not specfied, is 'rt' (round-trip)
    with open(args.yaml, "r") as rp:
        yaml_data = yaml.load(rp)

    try:
        asyncio.run(main(yaml_data, args.algo, args.server))
    except KeyboardInterrupt as e:
        LOG.error("keyboard interrupt received; exiting")
