#!/usr/bin/env python
"""Pulse-to-pulse feedback using epics variables

Available

The data path is below, with the interfaces all done using queues

    p4p subscribers -> epics_read -> algo -> epics_write

A separate control task will also be run in a separate loop, but as
everything is driven by the simulator, this should be kept separate.

A setup coroutine is also available for use, but again, should likely not
be used."""
import os
import threading
import asyncio

import logging

logging.basicConfig()
LOG = logging.getLogger()

try:
    from wfs_data_receive import main as rxmain
    from wfs_data_send import main as txmain
except ImportError as e:
    print(e)


class asyncthread(threading.Thread):
    """Class to run an asyncio loop in a thread"""

    def run(self):
        LOG.info("running")
        asyncio.run(self._target(*self._args, **self._kwargs))


class ThreadManagementWrapper:
    """Wrapper for thread to avoid starting multiple times"""
    def start(self, *args, **kwargs):
        try:
            if self.thread.is_alive():
                LOG.warning("Thread is already alive; ignoring")
                return
        except AttributeError:
            self.thread = asyncthread(*args, **kwargs)
        return self.thread.start()


if __name__ == "__main__":
    from tkinter import *
    from tkinter import filedialog as fd
    from tkinter import ttk

    # from tkinter.scrolledtext import ScrolledText

    from ruamel.yaml import YAML

    # Main TK application
    root = Tk()
    root.title("WFS Send/Receive Manager")
    # root.geometry("300x500")

    class ConfigData:
        """Dataclass with a minor data loading"""

        yname = StringVar()
        yamlstr = StringVar()
        addr = StringVar()

        def __init__(self):
            self.yname.set("./data.yml")
            self.addr.set("tcp://127.0.0.1:5555")
            self.load_yaml()

        def load_yaml(self):
            # Load YAML configuration for algorithms
            self.yaml_parser = YAML(
                typ="safe"
            )  # default, if not specfied, is 'rt' (round-trip)
            with open(self.yname.get(), "r") as rp:
                raw = rp.read()
            self.yaml = self.yaml_parser.load(raw)
            self.yamlstr.set(raw)

    cfg = ConfigData()

    def select_file(idata):
        """File dialog and yaml loading"""
        filetypes = (("YAML files", ("*.yml", "*.yaml")), ("All files", "*.*"))

        filename = fd.askopenfilename(
            title="Open a file", initialdir=os.getcwd(), filetypes=filetypes
        )

        idata.yname.set(filename)
        idata.load_yaml()

    # Branding
    bg_image = PhotoImage(file="./radiasoft_color_transparent_scaled.png")
    # ttk.Label(root, image=bg_image).place(x=0, y=-50, relwidth=1, relheight=1)
    ttk.Label(root, image=bg_image).grid(column=0, row=0)

    # Main container
    frm = ttk.Frame(root, padding=10)
    frm.grid()

    # Set log level dynamically
    level = StringVar()
    level.set("warning")
    logdict = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
    }
    LOG.setLevel(logdict[level.get()])

    def log_level_cb(event):
        LOG.setLevel(logdict[level.get()])

    logcb = ttk.Combobox(
        frm, textvariable=level, values=tuple(logdict.keys()), state="readonly"
    )
    ttk.Label(frm, text="Log Level").grid(column=3, row=0)
    logcb.grid(column=4, row=0)
    logcb.bind("<<ComboboxSelected>>", log_level_cb)

    # Other Configuration fields
    ttk.Label(frm, text="Server Address").grid(column=0, row=0)
    ttk.Entry(frm, textvariable=cfg.addr).grid(column=1, row=0, columnspan=2)

    ttk.Label(frm, text="Selected YAML").grid(column=0, row=1)
    ttk.Entry(frm, textvariable=cfg.yname, state="readonly").grid(
        column=1, row=1, columnspan=2
    )

    ttk.Button(
        frm, text="Select YAML config", command=lambda arg=cfg: select_file(cfg)
    ).grid(column=3, row=1)

    # Buttons

    txt = ThreadManagementWrapper()
    ttk.Button(
        frm,
        text="Start Camera Send",
        command=lambda arg1=cfg.yaml["send"].copy(), arg2=cfg.addr.get(): txt.start(
            target=txmain, daemon=True, args=[arg1, arg2]
        ),
    ).grid(column=1, row=3)

    rxt = ThreadManagementWrapper()
    ttk.Button(
        frm,
        text="Start Data Receive",
        command=lambda arg1=cfg.yaml[
            "receive"
        ].copy(), arg2="pid", arg3=cfg.addr.get(): rxt.start(
            target=rxmain, daemon=True, args=[arg1, arg2, arg3]
        ),
    ).grid(column=1, row=4)

    ttk.Button(frm, text="Exit", command=root.destroy).grid(column=1, row=5)

    # Run main loop
    root.mainloop()
