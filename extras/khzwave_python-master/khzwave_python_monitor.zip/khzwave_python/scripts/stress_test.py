#!/usr/bin/env python
"""Pulse-to-pulse feedback using epics variables

Available

The data path is below, with the interfaces all done using queues

    p4p subscribers -> epics_read -> algo -> epics_write

A separate control task will also be run in a separate loop, but as
everything is driven by the simulator, this should be kept separate.

A setup coroutine is also available for use, but again, should likely not
be used."""
import os
import asyncio
import time
import numpy as np
import h5py

# Faster loop handling
# ~ import uvloop
# ~ asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

from khzwave.zaber import ZaberStage

from ruamel.yaml import YAML

import logging

logging.basicConfig()

files = (
    "ROC vs time 1080 x 1080 2 ms exposure kHz trigger",
    "ROC vs time 768 x 768 2 ms exposure kHz trigger",
    "ROC vs time 512 x 512 2 ms exposure kHz trigger",
    "ROC vs time 360 x 360 2 ms exposure kHz trigger",
)


def load_data_file(fname, fpath=""):
    LOG = logging.getLogger("data")

    fdata = []
    with open(os.path.join(fpath, fname), "r") as rp:
        for line in rp:
            time, value = line.split("\t")
            fdata.append((int(float(time)), float(value)))
    rawdata = np.asarray(fdata)
    LOG.info(f"Created dataset for {fname}")
    normdata = rawdata.copy()
    normdata[:, 0] = normdata[:, 0] - normdata[:, 0][0]
    return normdata, rawdata


async def main(args):
    LOG = logging.getLogger("main")

    zz = ZaberStage()
    await zz.open_asyn()

    # Center stage for test
    center = 12500000
    await zz.move_absolute(center)

    if args.resolution == "high":
        idx = 0
    else:
        idx = -1

    data, _ = load_data_file(files[idx], args.path)

    # remove data mean
    data_zero = data[:, 1] - data[:, 1].mean()

    # Update for ratio of correction element to focal shift
    ratio = 2
    data_zero /= ratio

    # Update mm to nm
    data_zero *= 1000000
    data_zero_int = data_zero.astype(int)

    # do at same difference (20 ms, can't do) or instead update at 10 Hz? Lets try that
    # Use a decimation to filter properly in time?

    timediff = 0
    activeidx = 0
    loopidx = 0
    starttime = time.time()
    runtime = 0
    goaltime = 0.2
    lastval = 0

    if args.home:
        await zz.home()

    csvf = open("stress_test_data.csv", "w", buffering=1)
    csvf.write(
        f"start,timediff,steps,system.temperature,system.voltage,driver.temperature\n"
    )
    loop_channels = {
        "system.temperature": 0,
        "system.voltage": 0,
        "driver.temperature": 0,
    }

    while time.time() - starttime < int(args.hours * 60 * 60):
        loopstarttime = time.time()

        # Do move and capture, with scope if at a scope point
        steps = data_zero_int[activeidx] + center
        LOG.info("Moving to %d steps" % steps)
        start = time.time_ns()

        if args.scope:
            if loopidx % 20 == 0:
                # await zz.move_and_capture_scope(steps, absolute=True, home_device=False, save=True, buffsize=2000)
                await zz.arm_scope()
                await zz.start_scope(buffsize=2000)
                await zz.move_absolute(steps)
                activeidx += 1
                activeidx = activeidx % data_zero_int.shape[0]
                steps = data_zero_int[activeidx] + center
                await zz.move_absolute(steps)
                await zz.get_scope_data(save=True)
            else:
                xx = await zz.move_absolute(steps)
                if b"BUSY" in xx and not args.fast:
                    await zz.wait_idle()

            # Record time needed
            timediff = time.time_ns() - start

        else:
            xx = await zz.move_absolute(steps)
            if b"BUSY" in xx and not args.fast:
                await zz.wait_idle()

            # Record time needed
            timediff = time.time_ns() - start

            if loopidx % 100 == 0:
                # Get temperatures and voltage
                for chan in loop_channels.keys():
                    cmd = f"/1 get {chan}\n".encode()
                    l = await zz.do_serial_trans(cmd)
                    loop_channels[chan] = float(l[1].split(b" ")[-1])
                    LOG.debug("%s: %s" % (chan, loop_channels[chan]))

        csvf.write(
            f"{start},{timediff},{steps},{loop_channels['system.temperature']},{loop_channels['system.voltage']},{loop_channels['driver.temperature']}\n"
        )

        LOG.info("Move took %d nanoseconds" % timediff)

        activeidx += 1

        if activeidx >= data_zero.shape[0]:
            activeidx = 0

        loopidx += 1

        # Adjust waittime in loop
        looptime = time.time() - loopstarttime
        waittime = goaltime - looptime

        # Sleep around 100 ms if calculated waittime is greater than 5 ms
        if waittime > 0.005:
            time.sleep(waittime)


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description="Stress test Zaber stage")
    parser.add_argument("-t", "--hours", type=float, help="number of hours to run for")
    parser.add_argument(
        "-r",
        "--resolution",
        type=str,
        choices=("high", "low"),
        default="low",
        help="number of hours to run for",
    )
    parser.add_argument(
        "-o", "--home", action="store_true", help="home device on startup"
    )
    parser.add_argument(
        "-p", "--path", type=str, default="", help="path for source files"
    )
    parser.add_argument("-s", "--scope", action="store_true", help="capture scope data")
    parser.add_argument("-f", "--fast", action="store_true", help="run in fast mode")
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="use info level output"
    )
    parser.add_argument(
        "-vv", "--vverbose", action="store_true", help="use debug level output"
    )
    args = parser.parse_args()

    # Logging level default verbosity
    LOG = logging.getLogger()

    if args.verbose:
        LOG.setLevel(logging.INFO)

    if args.vverbose:
        LOG.setLevel(logging.DEBUG)

    try:
        returnval = asyncio.run(main(args))
        LOG.error("%s" % returnval)
    except KeyboardInterrupt as e:
        LOG.error("keyboard interrupt received; exiting")
