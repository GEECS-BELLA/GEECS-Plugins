#!/usr/bin/env python
"""Pulse-to-pulse feedback using epics variables

Available

The data path is below, with the interfaces all done using queues

    p4p subscribers -> epics_read -> algo -> epics_write

A separate control task will also be run in a separate loop, but as
everything is driven by the simulator, this should be kept separate.

A setup coroutine is also available for use, but again, should likely not
be used."""
import os
import asyncio
import pickle
import socket
import ctypes
from time import time_ns, sleep
import numpy as np

from ruamel.yaml import YAML

from khzwave import wfs

import zmq
from zmq.utils.monitor import recv_monitor_message
import zmq.asyncio

import logging

logging.basicConfig()


def monitor():
    return []


def wfs_acquire_and_calc(wfs: wfs.Wfs20Instrument, order=3):
    """Trigger image capture and process data before pulling it

    Based on high-speed capture process"""
    wfs.takeSpotfieldImage()
    if not wfs.hs_mode:
        wfs.calcBeamCentroidDia()  # Not available in high-speed mode
    wfs.calcBeamInformation()
    if wfs.info.centroid_x == NaN:
        raise RuntimeError("NaN value received for centroid")
    wfs.calcSpotToReferenceDeviations()
    wfs.calcZernikeLSF(order=3)  # Defaults to orders=4
    return True


def wfs_centroid(wfs: wfs.Wfs20Instrument, do_acquisition=True):
    if do_acquisition:
        wfs_acquire_and_calc(wfs)
    wfs.getSpotCentroids()
    # calcBeamCentroidDia()
    # wfs.info.centroid_x, wfs.info.centroid_y, wfs.info.diameter_x, wfs.info.diameter_y),
    # getSpotIntensities()
    # wfs.img.intensities
    return {"centroidx": wfs.img.arrayCentroidsX, "centroidy": wfs.img.arrayCentroidsY}


def wfs_spotfield(wfs: wfs.Wfs20Instrument, do_acquisition=True):
    if do_acquisition:
        wfs_acquire_and_calc(wfs)
    wfs.getSpotfieldImage()
    wfs.buildSpotfieldImageArray()
    return {"image": wfs.img.SpotfieldImage}


def wfs_zernike_roc(wfs: wfs.Wfs20Instrument, orders: int = 3, do_acquisition=True):
    """Coefficients, orders, and radius of curvature as calculate by driver

    Based on wfs.dll.defines["MAX_ZERNIKE_MODES"]"""
    if do_acquisition:
        wfs_acquire_and_calc(wfs)
    nzernikes = orders * (orders + 1) // 2
    zernike_coef = wfs.img.arrayZernikeUm[:nzernikes]
    zernike_orders_rms = wfs.img.arrayZernikeOrdersUm[:orders]
    roc_mm = wfs.img.roCMm.value
    return {"coef": zernike_coef, "orders": zernike_orders_rms, "roc": roc_mm}


# Possible data to retrieve from driver
AVAILABLE_DATA_FORMATS = {
    "centroid": wfs_centroid,
    "spotfield": wfs_spotfield,
    "roc": wfs_zernike_roc,
}


def bypass(inputs):
    return inputs


# Possible data reduction algorithms
REDUCE_ALGORITHMS = {
    "bypass": bypass,
}


class WfsDummyDataGen:
    """Dummy data generator to properly set RNG seed"""

    def __init__(self, algo="random", shape=(100, 4), seed=42):
        self.shape = shape
        self.seed = seed

        self.set_algo(algo)

    def set_algo(self, algo):
        self.algo = algo
        if self.algo == "random":
            try:
                self._rng
            except AttributeError:
                self._rng = np.random.default_rng(seed=self.seed)
        else:
            raise ArgumentError("Unrecognized algorithm %s" % algo)

    def __call__(self):
        if self.algo == "random":
            return {"data": self._rng.random(self.shape)}


async def wfs_read(yaml, queue: asyncio.Queue):
    """Subscribes to READPVS and aggregates data into a single item for algorithm"""

    LOG = logging.getLogger("wfs_read")

    if not yaml["use_dummy"]:
        from khzwave import wfs

        # Initialize interface to WFS driver
        wfs_intf = wfs.WfsInterface()

        # Initialize WFS20 device class
        wfs_dev = wfs.Wfs20Instrument(wfs_intf)

        # Configure camera
        # Set resolution and pixel format
        LOG.info("Configuring camera to PIXEL_FORMAT_MONO8 and CAM_RES_WFS20_1440")
        err = wfs_dev.dll.WFS_ConfigureCam(
            wfs_dev.handle,
            wfs_dev.dll.defines["PIXEL_FORMAT_MONO8"],
            # Fastest "normal" mode that can change to HS mode
            wfs_dev.dll.defines["CAM_RES_WFS20_1440"],
            ctypes.byref(wfs_dev.info.spots_x),
            ctypes.byref(wfs_dev.info.spots_y),
        )
        wfs_dev.handleError(err)

        # wfs_dev.configureCamera()
        LOG.debug(
            "spots x,y: %d, %d"
            % (wfs_dev.info.spots_x.value, wfs_dev.info.spots_y.value)
        )

        # Set exposure, use default master gain of 1
        wfs_dev.setExposureGain(exposureTime=yaml["camera"]["exposureTime"])

        # Setup reference plane and pupils
        wfs_dev.setInternalReferencePlane()
        wfs_dev.setPupil(
            yaml["camera"]["centroid_x"],
            yaml["camera"]["centroid_y"],
            yaml["camera"]["diameter_x"],
            yaml["camera"]["diameter_y"],
        )
        wfs_dev.getPupil()
        LOG.debug(
            "centroid x,y: %d, %d"
            % (wfs_dev.info.centroid_x.value, wfs_dev.info.centroid_x.value)
        )
        LOG.debug(
            "diameter x,y: %d, %d"
            % (wfs_dev.info.diameter_x.value, wfs_dev.info.diameter_y.value)
        )

        # Set trigger to HW mode
        wfs_dev.setTriggerMode(yaml["trigger"])
        mode = wfs_dev.getTriggerMode()
        LOG.info("Trigger mode set to %d" % mode.value)

        if yaml["camera"]["high_speed"]:
            wfs_dev.setHighSpeedMode(
                True,
                yaml["camera"]["adaptCentroids"],
                yaml["camera"]["numCutDigits"],
                yaml["camera"]["allowAutoExposure"],
            )

    while True:
        LOG.debug("Building queue futures and awaiting queue data")

        start = time_ns()

        if not yaml["use_dummy"]:
            # Get ROC and Zernike
            # TODO add in YAML configuration for data type
            read_data = AVAILABLE_DATA_FORMATS[yaml["data"]](wfs_dev)
        else:
            try:
                dgen
            except NameError:
                dparams = yaml["dummy"]
                dgen = WfsDummyDataGen(
                    algo=dparams["algo"], shape=dparams["shape"], seed=dparams["seed"]
                )

            read_data = dgen()

        read_data["acqtime_ns"] = time_ns()

        LOG.debug("Received data: %s" % (read_data))

        # Get a "work item" out of the queue.
        await queue.put(read_data)
        await queue.join()

        end = time_ns()
        duration = (end - start) / 1e9

        LOG.debug("Data receive took %.3f seconds" % duration)


async def algo(yaml, read_queue, write_queue):
    """Runs input data to algorithm and can update algorithm based on queue updates"""

    LOG = logging.getLogger("algo")
    set_algo = REDUCE_ALGORITHMS[yaml["reduce_algo"]]

    if yaml["save_data"]["save"]:
        import h5py

        hf = h5py.File(yaml["save_data"]["name"], "w")

    while True:
        # Get a "work item" out of the queue.
        in_item = await read_queue.get()

        LOG.debug("Processing %s" % in_item)

        # Run algorithm
        out_item = set_algo(in_item)

        # Notify the queue that the "work item" has been processed.
        read_queue.task_done()

        # Save data if requested
        if yaml["save_data"]["save"]:
            grp = hf.create_group(str(time_ns()))
            for k, v in out_item.items():
                grp.create_dataset(k, data=v)

        # Write out new values
        if yaml["send_data"]:
            await write_queue.put(out_item)
            await write_queue.join()


async def udp_send(yaml, queue, address=None):
    LOG = logging.getLogger("udp_send")

    # interfaces = socket.getaddrinfo(host=socket.gethostname(), port=None, family=socket.AF_INET)
    # allips = [ip[-1][0] for ip in interfaces]
    # LOG.debug("%s" % allips)

    sendip = yaml["sendip"]
    rxip = yaml["rxip"]
    port = yaml["port"]

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)  # UDP
    # sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.bind((sendip, port))

    LOG.info("Initializing UDP send loop")
    while True:
        # Get a "work item" out of the queue and send to subscribers
        read_item = await queue.get()
        LOG.debug("Sending %s" % read_item)
        read_bytes = pickle.dumps(read_item)
        # msglen = len(read_bytes).to_bytes(2, 'big')
        # msg = msglen + read_bytes
        msg = read_bytes

        result = sock.sendto(msg, (yaml["rxip"], yaml["port"]))
        LOG.debug("Sent %d bytes" % result)

        # Notify the queue that the "work item" has been processed.
        queue.task_done()


async def zmq_send(yaml, queue, address="tcp://127.0.0.1:5555"):
    """Writes received data from algorithm to epics control variables

    This isn't perfect -- if the client disconnects at just the wrong time,
    this can probably dead lock."""

    LOG = logging.getLogger("zmq_send")

    ctx = zmq.asyncio.Context()
    sock = ctx.socket(zmq.PUB)
    # zmq.Event.HANDSHAKE_SUCCEEDED | zmq.Event.DISCONNECTED
    monitor = sock.get_monitor_socket()
    sock.bind(address)
    LOG.debug("Socket open: %s" % sock)

    connected = False

    LOG.info("Initializing 0mq send loop")
    while True:
        # Await connection
        while not connected:
            result = await recv_monitor_message(monitor)
            LOG.debug("Received event: %s" % result)
            if result["event"] == zmq.Event.HANDSHAKE_SUCCEEDED:
                LOG.info("Client connected: %s" % result)
                connected = True

        # Get a "work item" out of the queue and send to subscribers
        read_item = await queue.get()
        LOG.debug("Sending %s" % read_item)

        # TODO change to faster method of bytes sending (numpy array sizes, etc)
        result = await sock.send_pyobj(read_item)
        LOG.debug("Send result %s" % result)

        # Notify the queue that the "work item" has been processed.
        queue.task_done()

        # Test if client disconnected
        try:
            result = await recv_monitor_message(monitor, flags=zmq.Flag.DONTWAIT)
            LOG.debug("Received event: %s" % result)
            if result["event"] == zmq.Event.DISCONNECTED:
                LOG.info("Client disconnected: %s" % result)
                connected = False
        except zmq.error.Again:
            pass


async def main(yaml, address):
    LOG = logging.getLogger("main")

    # Creating read and write data queues
    read_queue = asyncio.Queue(10)
    write_queue = asyncio.Queue(10)

    # Kick off tasks, handling UDP vs zmq case
    if yaml["use_zmq"]:
        send_thread = zmq_send
        send_yaml = yaml["send"]
    else:
        send_thread = udp_send
        send_yaml = yaml

    if yaml["send"]["send_data"]:
        results = await asyncio.gather(
            wfs_read(yaml["send"], read_queue),
            algo(yaml["send"], read_queue, write_queue),
            send_thread(send_yaml, write_queue, address=address),
        )
    else:
        results = await asyncio.gather(
            wfs_read(yaml["send"], read_queue),
            algo(yaml["send"], read_queue, write_queue),
        )

    # Python 3.11 and above
    # ~ async with asyncio.TaskGroup() as tg:
    # ~ rtask = tg.create_task("epics_read", epics_read(ctxt, read_queue, VARS_EPICS_READ))
    # ~ atask = tg.create_task("algorithm", algo(algo_queue,read_queue,write_queue))
    # ~ wtask = tg.create_task("epics_write", epics_write(ctxt,read_queue))


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(description="Start WFS20 sensor acquisition and 0mq server")
    parser.add_argument(
        "-a",
        "--address",
        default="tcp://127.0.0.1:5555",
        type=str,
        help="address to bind on",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="use info level output"
    )
    parser.add_argument(
        "-vv", "--vverbose", action="store_true", help="use debug level output"
    )
    parser.add_argument("yaml", type=str, help="YAML file for algorithm definition")
    args = parser.parse_args()

    # Logging level default verbosity
    LOG = logging.getLogger()

    if args.verbose:
        LOG.setLevel(logging.INFO)

    if args.vverbose:
        LOG.setLevel(logging.DEBUG)

    # Load YAML configuration for algorithms
    yaml = YAML(typ="safe")  # default, if not specfied, is 'rt' (round-trip)
    with open(args.yaml, "r") as rp:
        yaml_data = yaml.load(rp)

    try:
        asyncio.run(main(yaml_data, args.address))
    except KeyboardInterrupt as e:
        LOG.error("keyboard interrupt received; exiting")
