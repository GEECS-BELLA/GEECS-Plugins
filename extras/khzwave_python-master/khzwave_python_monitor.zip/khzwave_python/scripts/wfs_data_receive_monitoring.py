#!/usr/bin/env python
"""Pulse-to-pulse feedback using epics variables

Available

The data path is below, with the interfaces all done using queues

    p4p subscribers -> epics_read -> algo -> epics_write

A separate control task will also be run in a separate loop, but as
everything is driven by the simulator, this should be kept separate.

A setup coroutine is also available for use, but again, should likely not
be used."""
import os
import socket
import pickle
import threading
from time import time_ns
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import queue

import matplotlib.animation as animation
from matplotlib.lines import Line2D

from ruamel.yaml import YAML

import logging

logging.basicConfig()

dataq = queue.Queue()

class UdpThread(threading.Thread):
    """Thread to receive UDP stream from Thorlabs WFS20 host"""

    def __init__(self, q: queue.Queue, *args, name="udp", **kwargs):
        super().__init__(*args, name=name, **kwargs)
        self.q = q
        self.daemon = True
        
        LOG.info("Initial time is %d" % time_ns())

    def run(self):
        LOG = logging.getLogger("udp_read")

        rxip = "192.168.7.245"
        port = 32651

        rf = open("roc_data_thorlabs_wfs20.txt", "w")

        LOG.info("Initializing UDP receive loop")
        while True:
            start = time_ns()

            sock = socket.socket(
                socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP
            )  # UDP
            # sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.bind((rxip, port))
            msg = sock.recv(2048)
            sock.close()

            try:
                read_data = pickle.loads(msg)
            except Exception as e:
                LOG.error("Exception while unpickling idx %d: %s" % (idx, e))

            LOG.debug("Received data: %s" % read_data)

            # Write data to file
            if True:
                current_time = time_ns()
                wstr = f"{current_time} {read_data['roc']}\n" 
                rf.write(wstr)
                rf.flush()
                os.fsync(rf.fileno())

            # Get a "work item" out of the queue.
            self.q.put(read_data["roc"])
            self.q.join()
            end = time_ns()
            LOG.debug("RX loop took %d ns" % (end - start))


class DummyThread(threading.Thread):

    def __init__(self, q: queue.Queue, *args, name="udp", **kwargs):
        super().__init__(*args, name=name, **kwargs)
        self.q = q
        self.daemon = True

    def run(self):
        LOG = logging.getLogger("dummy_data")


        LOG.info("Initializing dummy receive loop")
        while True:
            data = np.random.rand(1)[0]
            data = data * 5 + 340

            LOG.debug("Sending data: %s" % data)

            # Get a "work item" out of the queue.
            self.q.put(data)
            self.q.join()


class Scope:
    def __init__(self, ax, nshots=500):
        self.ax = ax
        self.dt = 1
        self.maxt = nshots
        self.tdata = [0]
        self.ydata = [340]
        self.line = Line2D(self.tdata, self.ydata)
        self.ax.add_line(self.line)
        self.ax.set_ylim(332., 342.)
        self.ax.set_xlim(0, self.maxt)

    def update(self, y):
        lastt = self.tdata[-1]
        if lastt >= self.tdata[0] + self.maxt:  # reset the arrays
            self.tdata = [self.tdata[-1]]
            self.ydata = [self.ydata[-1]]
            self.ax.set_xlim(self.tdata[0], self.tdata[0] + self.maxt)
            self.ax.figure.canvas.draw()

        # This slightly more complex calculation avoids floating-point issues
        # from just repeatedly adding `self.dt` to the previous value.
        t = self.tdata[0] + len(self.tdata) * self.dt

        self.tdata.append(t)
        self.ydata.append(y)
        self.line.set_data(self.tdata, self.ydata)
        logging.debug("returning line for data %f" % y)
        return self.line,


def emitter(p=0.1):
    """Return an item from the queue"""
    while True:
        rdata = dataq.get()
        logging.debug("Sending %f in emitter" % rdata)
        dataq.task_done()
        yield rdata


def main(*args, **kwargs):

    LOG = logging.getLogger("main")
    
    LOG.info("Starting data threads")
    if kwargs["dummy"]:
        dummyt = DummyThread(dataq)
        dummyt.start()
    else:
        udpt = UdpThread(dataq)
        udpt.start()
    
    LOG.info("Creating animation")
    fig, ax = plt.subplots()
    scope = Scope(ax)

    # pass a generator in "emitter" to produce data for the update func
    ani = animation.FuncAnimation(fig, scope.update, emitter, interval=10,
                                  blit=True, save_count=100)

    LOG.info("Showing plot")
    plt.show(block=True)

if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser(
        description="Receive data from WFS20 0mq and write to Zaber stage"
    )
    parser.add_argument(
        "-s",
        "--server",
        default="tcp://127.0.0.1:5555",
        type=str,
        help="address to subscribe to",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="use info level output"
    )
    parser.add_argument(
        "-vv", "--vverbose", action="store_true", help="use debug level output"
    )
    parser.add_argument(
        "-d", "--dummy", action="store_true", help="use dummy data for scope"
    )
    # parser.add_argument("yaml", type=str, help="YAML file for algorithm definition")
    args = parser.parse_args()

    # Logging level default verbosity
    LOG = logging.getLogger()

    if args.verbose:
        LOG.setLevel(logging.INFO)

    if args.vverbose:
        LOG.setLevel(logging.DEBUG)

    mplf = logging.getLogger("matplotlib.font_manager")
    mplf.setLevel(logging.CRITICAL)
    

    # Load YAML configuration for algorithms
    # yaml = YAML(typ="safe")  # default, if not specfied, is 'rt' (round-trip)
    # with open(args.yaml, "r") as rp:
        # yaml_data = yaml.load(rp)

    try:
        main(dummy=args.dummy)
    except KeyboardInterrupt as e:
        LOG.error("keyboard interrupt received; exiting")
