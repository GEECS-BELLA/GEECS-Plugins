#!/bin/bash
pdoc -d restructuredtext -o _docs src/khzwave/
